import cv2 as cv

print(cv.getBuildInformation())
